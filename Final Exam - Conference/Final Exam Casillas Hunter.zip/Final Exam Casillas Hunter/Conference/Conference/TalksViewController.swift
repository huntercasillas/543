//
//  TalksViewController.swift
//  Conference
//
//  Created by Hunter Casillas on 12/19/19.
//  Copyright © 2019 Hunter Casillas. All rights reserved.
//

import UIKit

class TalksViewController: UITableViewController {
    
    override func viewDidLoad() { 
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var talks: [Talk]!
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Talks", for: indexPath)
        let talkTitle = talks[indexPath.row].title.replacingOccurrences(of: "&ldquo;", with: "\"").replacingOccurrences(of: "&rdquo;", with: "\"").replacingOccurrences(of: "&mdash;", with: "—").replacingOccurrences(of: "&rsquo;", with: "'")
        cell.textLabel?.text = talkTitle
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return talks.count
    }
        
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "Show Talk", sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Show Talk" {
            let navigation = segue.destination as? UINavigationController
            if let destination = navigation?.topViewController as? WebViewController {
                if let indexPath = tableView.indexPathForSelectedRow {
                    let talkTitle = talks[indexPath.row].title.replacingOccurrences(of: "&ldquo;", with: "\"").replacingOccurrences(of: "&rdquo;", with: "\"").replacingOccurrences(of: "&mdash;", with: "—").replacingOccurrences(of: "&rsquo;", with: "'")
                    destination.talk = talks[indexPath.row]
                    destination.title = talkTitle
                }
            }
        }
    }
}
