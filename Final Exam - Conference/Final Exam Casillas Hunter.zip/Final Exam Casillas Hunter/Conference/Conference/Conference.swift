//
//  Conference.swift
//  Conference
//
//  Created by Hunter Casillas on 12/19/19.
//  Copyright © 2019 Hunter Casillas. All rights reserved.
//

import GRDB

struct Conference : TableRecord, FetchableRecord {
    
    struct Table {
        static let databaseTableName = "conference"
        static let id = "ID"
        static let abbr = "Abbr"
        static let description = "Description"
        static let year = "Year"
        static let annual = "Annual"
        static let issueDate = "IssueDate"
    }
    
    var id: Int
    var abbr: String
    var description: String
    var year: String
    var annual: String
    var issueDate: String
        
    init() {
        id = 0
        abbr = ""
        description = ""
        year = ""
        annual = ""
        issueDate = ""
    }

    init(row: Row) {
        id = row[Table.id]
        abbr = row[Table.abbr]
        description = row[Table.description]
        year = row[Table.year]
        annual = row[Table.annual]
        issueDate = row[Table.issueDate]
    }
}
