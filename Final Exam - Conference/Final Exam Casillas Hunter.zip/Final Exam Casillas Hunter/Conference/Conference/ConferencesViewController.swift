//
//  ConferencesViewController.swift
//  Conference
//
//  Created by Hunter Casillas on 12/19/19.
//  Copyright © 2019 Hunter Casillas. All rights reserved.
//

import UIKit

class ConferencesViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    let conferences = LocalDatabase.shared.conferences()
        
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Conferences", for: indexPath)
        cell.textLabel?.text = conferences[indexPath.row].abbr
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conferences.count
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Show Talks" {
            if let destination = segue.destination as? TalksViewController {
                if let indexPath = tableView.indexPathForSelectedRow {
                    let conferenceID = conferences[indexPath.row].id
                    destination.talks = LocalDatabase.shared.talksForConferenceID(conferenceID)
                    destination.title = conferences[indexPath.row].abbr
                }
            }
        }
    }
}
