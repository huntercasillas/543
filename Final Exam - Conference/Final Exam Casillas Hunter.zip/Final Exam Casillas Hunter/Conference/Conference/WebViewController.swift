//
//  WebViewController.swift
//  Conference
//
//  Created by Hunter Casillas on 12/19/19.
//  Copyright © 2019 Hunter Casillas. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController, WKNavigationDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        webView.navigationDelegate = self
        loadTalk()
    }
    
    var talk : Talk!
    @IBOutlet weak var webView: WKWebView!
    
    func loadTalk() {
        if talk != nil {
            let link = "https://scriptures.byu.edu/content/talks_ajax/\(talk.id)"
            let url = URL(string: link)
            webView.load(URLRequest(url: url!))
        }
    }
}
