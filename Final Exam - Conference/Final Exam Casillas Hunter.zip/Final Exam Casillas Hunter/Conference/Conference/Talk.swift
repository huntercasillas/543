//
//  Talk.swift
//  Conference
//
//  Created by Hunter Casillas on 12/19/19.
//  Copyright © 2019 Hunter Casillas. All rights reserved.
//

import GRDB

struct Talk : TableRecord, FetchableRecord {
    
    struct Table {
        static let databaseTableName = "talk"
        static let id = "ID"
        static let title = "Title"
        static let description = "Description"
    }
    
    var id: Int
    var title: String
    var description: String
        
    init() {
        id = 0
        title = ""
        description = "" 
    }

    init(row: Row) {
        id = row[Table.id]
        title = row[Table.title]
        description = row[Table.description]
    }
}
