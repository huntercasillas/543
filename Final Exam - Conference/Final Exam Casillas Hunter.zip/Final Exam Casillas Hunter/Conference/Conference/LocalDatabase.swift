//
//  LocalDatabase.swift
//  Conference
//
//  Created by Hunter Casillas on 12/19/19.
//  Copyright © 2019 Hunter Casillas. All rights reserved.
//

import GRDB

class LocalDatabase {
    
    struct Constant {
        static let fileName = "core.37"
        static let fileExtension = "db"
    }
    
    var dbQueue: DatabaseQueue
    static let shared = LocalDatabase()

    private init() {
        if let path = Bundle.main.path(forResource: Constant.fileName,
                                       ofType: Constant.fileExtension) {
            if let queue = try? DatabaseQueue(path: path) {
                dbQueue = queue
                return
            }
        }

        fatalError("Unable to connect to database")
    }

    // Return a Talk object for the given talk ID.
    func talkForID(_ talkID: Int) -> Talk {
        do {
            let talk = try dbQueue.inDatabase { (db: Database) -> Talk in
                let row = try Row.fetchOne(db,
                                           sql: """
                                                select * from \(Talk.Table.databaseTableName) \
                                                where \(Talk.Table.id) = ?
                                                """,
                                           arguments: [ talkID ])
                if let returnedRow = row {
                    return Talk(row: returnedRow)
                }

                return Talk()
            }
            
            return talk
        } catch {
            return Talk()
        }
    }
    
    // Return array of Talk objects for the given conference ID (i.e. parent talk ID).
    func talksForConferenceID(_ parentTalkID: Int) -> [Talk] {
        do {
            let talks = try dbQueue.inDatabase { (db: Database) -> [Talk] in
                var talks = [Talk]()
                let rows = try Row.fetchCursor(db,
                                               sql: """
                                                    select t.ID, t.Title, s.Description from talk t \
                                                    join conference_talk c join conf_session s \
                                                    where t.ID=c.TalkID and c.SessionID=s.ID \
                                                    and s.ConferenceID = ? \
                                                    order by s.Sequence, c.Sequence
                                                    """,
                                               arguments: [ parentTalkID ])
                while let row = try rows.next() {
                    talks.append(Talk(row: row))
                }

                return talks
            }

            return talks
        } catch {
            return []
        }
    }

    // Return array of all Conference objects
    func conferences() -> [Conference] {
        do {
            let conferences = try dbQueue.inDatabase { (db: Database) -> [Conference] in
                var conferences = [Conference]()
                let rows = try Row.fetchCursor(db,
                                               sql: """
                                                    select * from \(Conference.Table.databaseTableName) \
                                                    order by \(Conference.Table.issueDate) desc
                                                    """)
                while let row = try rows.next() {
                    conferences.append(Conference(row: row))
                }

                return conferences
            }
            
            return conferences
        } catch {
            return []
        }
    }
}
